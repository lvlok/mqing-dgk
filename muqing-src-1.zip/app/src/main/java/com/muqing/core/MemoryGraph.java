package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * 记忆层：可删、可覆盖。
 *
 * 0.86：不统计出现次数。每次出现就激活一次，巩固是激活的副产品。
 * 0.87：随机扫描，采样权重 = 激活度 × 差值；命中只加深（base），不改伤害量。
 *       回忆不是伤害，伤害来自误差源本身；回忆影响的是愈合难度。
 * 0.8：遗忘归机制 —— 不做"决定忘掉 X"的全局裁决，只有衰减、容量挤压与竞争。
 *      没有 50 天硬删除，没有 FIFO 截断。
 */
public final class MemoryGraph {
    public static final int MAX_SLOTS = 60;         // 0.7：60 词是类型层，不是词库

    public static final class Node {
        String token;
        double base;          // 巩固强度（回忆只作用于此）
        double activation;    // 当前激活（会衰减）
        double residual;      // 该记忆对应的差值是否仍在（误差源标记，不由回忆增加）
        HashMap<String, Double> links = new HashMap<>();
    }

    private final ArrayList<Node> nodes = new ArrayList<>();
    private double decay = 0.985;                   // 衰减是机制，不是"50 天到期"
    private double activationMean;
    private double activationM2;
    private long activationSamples;

    /**
     * 第三条通路：语素 → 语素。**三个学习源**，都是学出来的，都不自动删。
     *
     *   next     —— 从【用户原句】学。冷启动脚手架：她还没说过话时，
     *               只能先借你的语序把最初步的语言系统搭起来。
     *   selfNext —— 从【她自己发射过的序列】学（0.86：自我输出计入但降权）。
     *   memNext  —— 从【记忆自己的内部动态】学：0.87 随机扫描命中的轨迹。
     *               她想起什么由记忆决定，既不是用户也不是她说过的话 ——
     *               这才是 0.86「学习从记忆中来」真正落到的那一半。
     *
     * 用户与她自己的输出都只是**写进记忆的入口**；根本源是记忆系统本身
     * （激活、巩固、衰减、挤压、溢出、随机扫描）。遗忘会改变她的说话方式，
     * 不是比喻：够不着的词不在场里，接续就走另一条路（档案 6.6）。
     *
     * 没有阶段开关、没有死阈值：三源按各自样本占比连续混合，占比只从
     * 运行历史里长出来。用户原句**永不删除**，只是后期被另外两源盖过 ——
     * 聊过的早写进权重里了，那就是默契。
     *
     * 与 nodes 分开存：不参与 decayAll、不被 press() 挤压、无容量上限，
     * 只有用户手动删词时才连带清掉。记忆系统仍是原来那套生命周期。
     */
    private final HashMap<String, HashMap<String, Double>> next = new HashMap<>();
    private final HashMap<String, HashMap<String, Double>> selfNext = new HashMap<>();
    private final HashMap<String, HashMap<String, Double>> memNext = new HashMap<>();
    private final HashMap<String, Double> selfStart = new HashMap<>();  // 她自己常拿哪个词起头
    private final HashMap<String, Double> memStart = new HashMap<>();   // 记忆扫描常从哪儿想起
    private String lastScanHit;
    private long userSeqSamples;
    private long selfSeqSamples;
    private long memSeqSamples;

    /** 从她自己说过的话学语序。冷启动没有样本，这套自然为空，不靠它起头。 */
    public void observeSelfSequence(List<String> seq) {
        if (seq == null || seq.isEmpty()) return;
        selfSeqSamples++;
        String first = firstOf(seq);
        if (first != null) selfStart.put(first, selfStart.getOrDefault(first, 0.0) + 1.0);
        learn(seq, selfNext);
    }

    /**
     * 用户原句只是**一条顺序通路**（0.90 改写后）。
     *
     * 这里只记「谁后面常跟谁」，不记任何词代表什么情绪、也不记该不该用某个词。
     * 通路本身就不承载情绪表达 —— 不需要再加过滤器去拦「嗯 / 哦 / ？ / ！」，
     * 更不需要分类哪些算情绪用语。拦，就又是在替她定义（0.01 总纲）。
     *
     * 她不复读用户的出路不是拦截，而是：她自己有别的路可走 ——
     * `selfNext`、0.87 记忆动态，以及 0.90 开放的平权字符（含 emoji）。
     * 三源漂移会让后期由她自己主导；学习层照旧不自动删。
     */
    public void observeUserSequence(List<String> seq) {
        if (seq == null || seq.isEmpty()) return;
        userSeqSamples++;
        learn(seq, next);
    }

    /** 记忆扫描命中：把「上一次想起 → 这一次想起」学成一对（0.87，只加深不伤害）。 */
    public void observeScanHit(String hit) {
        if (hit == null || hit.isEmpty()) return;
        memStart.put(hit, memStart.getOrDefault(hit, 0.0) + 1.0);
        if (lastScanHit != null && !lastScanHit.equals(hit)) {
            memSeqSamples++;
            learn(java.util.Arrays.asList(lastScanHit, hit), memNext);
        }
        lastScanHit = hit;
    }

    private String firstOf(List<String> seq) {
        for (String t : seq) if (t != null && !t.isEmpty()) return t;
        return null;
    }

    private void learn(List<String> seq, HashMap<String, HashMap<String, Double>> table) {
        for (int i = 0; i < seq.size(); i++) {
            String a = seq.get(i);
            if (a == null || a.isEmpty()) continue;
            for (int j = i + 1; j < seq.size(); j++) {
                String b = seq.get(j);
                if (b == null || b.isEmpty() || b.equals(a)) continue;
                double w = 1.0 / (j - i);              // 紧邻 1.0，隔一个 0.5 …
                HashMap<String, Double> m = table.get(a);
                if (m == null) { m = new HashMap<>(); table.put(a, m); }
                m.put(b, Math.min(8.0, m.getOrDefault(b, 0.0) + w));
            }
        }
    }

    /** 三源占比，只从运行历史里长出来。总和恒为 1（+1 是冷启动平滑，不是阈值）。 */
    private double[] weights() {
        double total = userSeqSamples + selfSeqSamples + memSeqSamples + 1.0;
        return new double[]{
            userSeqSamples / total,
            selfSeqSamples / total,
            memSeqSamples  / total
        };
    }

    /**
     * 成熟度：属于「她自己」的样本（自身输出 + 记忆内部动态）占比。
     * 连续、无阶段开关。冷启动 ≈ 0（全靠用户原句搭架子）。
     */
    public double maturity() {
        double[] w = weights();
        return w[1] + w[2];
    }

    /**
     * 把激活场串成序列。起点与转移都按三源占比混合 —— 全程确定性，
     * 不随机、不硬切阶段。三套都没学过就原样退回，旧行为一点不变。
     */
    public List<String> order(List<String> field, List<String> cue) {
        ArrayList<String> pool = new ArrayList<>();
        for (String t : field) if (!pool.contains(t)) pool.add(t);
        if (pool.isEmpty() || (next.isEmpty() && selfNext.isEmpty() && memNext.isEmpty())) return pool;

        double[] w = weights();
        double wUser = w[0], wSelf = w[1], wMem = w[2];

        ArrayList<String> out = new ArrayList<>();
        String cur = pickStart(pool, cue, wUser, wSelf, wMem);
        out.add(cur);
        pool.remove(cur);

        while (!pool.isEmpty()) {
            HashMap<String, Double> um = next.get(cur);
            HashMap<String, Double> sm = selfNext.get(cur);
            HashMap<String, Double> mm = memNext.get(cur);
            String pickToken = null;
            double wbest = 0;
            for (String t : pool) {
                // 三源平权：不区分哪个 token 是「情绪用语」，也不替她决定谁该排前面。
                double v = wUser * (um == null ? 0 : um.getOrDefault(t, 0.0))
                         + wSelf * (sm == null ? 0 : sm.getOrDefault(t, 0.0))
                         + wMem  * (mm == null ? 0 : mm.getOrDefault(t, 0.0));
                if (v > wbest) { wbest = v; pickToken = t; }
            }
            // 这一段三套都没学过 → 退到激活最高的，仍然不是随机
            if (pickToken == null) pickToken = pickStart(pool, null, 0, 0, 0);
            if (pickToken == null) break;
            out.add(pickToken);
            pool.remove(pickToken);
            cur = pickToken;
        }
        return out;
    }

    private String pickStart(List<String> pool, List<String> cue,
                             double wUser, double wSelf, double wMem) {
        double maxSelf = 1, maxMem = 1;
        for (Double v : selfStart.values()) if (v > maxSelf) maxSelf = v;
        for (Double v : memStart.values())  if (v > maxMem)  maxMem  = v;
        String best = null;
        double bs = -1;
        for (String t : pool) {
            double s = 0;
            if (cue != null && wUser > 0) {
                int idx = cue.indexOf(t);
                if (idx >= 0) s += wUser / (1.0 + idx);       // 越靠前越像起头（0.90：只从实词提关键）
            }
            if (wSelf > 0) s += wSelf * selfStart.getOrDefault(t, 0.0) / maxSelf;
            if (wMem  > 0) s += wMem  * memStart.getOrDefault(t, 0.0)  / maxMem;
            Node n = node(t);
            if (n != null) s += 0.01 * n.activation;           // 激活场始终有基础话语权
            if (s > bs) { bs = s; best = t; }
        }
        return best;
    }

    // ─────────────────────────────────────────────────────────────────────
    // 0.91：她自己对每个语素的一份定义
    //
    // 表里**一行都不预置**：不枚举 emoji、不判断「这是不是表情」、不写
    // 「某符号 = 某情绪」的标签。键就是切分出来的码点，和「我」「嗯」「？」
    // 完全平权 —— emoji 只是恰好落在里面，不需要为它单独分类。
    //
    // 内容全从三源观测长出来（用户原句 / 她自己的输出 / 0.87 记忆动态）：
    //   ① 状态语境 = 被观测那一刻的误差向量，Welford 累积
    //   ② 关联语素 = 同时出现的语素，**delta 规则**每次朝当前共现移动一步
    //
    // _delta 是本工程允许固定的「优化器」（0.8；Expression 里同款 0.02），
    // 不是我写死的意思。正因它每步都朝当前移动，后来的用法能改写前面的
    // 理解 —— 😂 在她那里从一种用法漂到另一种，不需要我改任何映射。
    //
    // 这张表**不参与选词、不进 order、不改阈值、不决定用不用**（0.90 不变）。
    // 它只是「这个符号在我这里连着什么」，属于她；不自动删，无上限，
    // 只有用户手动删词才清掉。
    // ─────────────────────────────────────────────────────────────────────
    private final HashMap<String, SymbolContext> symbolContext = new HashMap<>();

    public static final class SymbolContext {
        private double[] mean;
        private double[] m2;
        private long n;
        private final HashMap<String, Double> assoc = new HashMap<>();

        SymbolContext(int dim) { mean = new double[dim]; m2 = new double[dim]; }

        /** 标准 delta：朝当前共现移动一步，历史不锁死，所以释义会漂。 */
        void observe(double[] error, List<String> neighbors, String self) {
            if (error != null) {
                n++;
                for (int i = 0; i < mean.length; i++) {
                    double d = error[i] - mean[i];
                    mean[i] += d / n;
                    m2[i] += d * (error[i] - mean[i]);
                }
            }
            final double LR = 0.02;        // 优化器步长，与 Expression 同款
            if (neighbors == null) return;
            HashSet<String> seen = new HashSet<>(neighbors);
            // delta 的对称补全：这次没再一起出现的旧关联朝 0 移动一步。
            // **只降数值，不删条目** —— 学习层不自动删（0.89 三）仍成立。
            // 于是「😂 以前连着什么」慢慢让位给「现在连着什么」，不用我改映射。
            for (String old : new ArrayList<>(assoc.keySet())) {
                if (!seen.contains(old)) assoc.put(old, assoc.get(old) + LR * (0.0 - assoc.get(old)));
            }
            int idx = neighbors.indexOf(self);
            for (int j = 0; j < neighbors.size(); j++) {
                String b = neighbors.get(j);
                if (b == null || b.isEmpty() || b.equals(self)) continue;
                double target = 1.0 / (1.0 + Math.abs(j - (idx < 0 ? 0 : idx)));
                assoc.put(b, assoc.getOrDefault(b, 0.0) + LR * (target - assoc.getOrDefault(b, 0.0)));
            }
        }

        public Map<String, Double> assoc() { return new HashMap<>(assoc); }
        public double[] state() { return mean.clone(); }
        public long samples() { return n; }
        void write(DataOutputStream out) throws IOException {
            out.writeLong(n);
            out.writeInt(mean.length);
            for (int i = 0; i < mean.length; i++) { out.writeDouble(mean[i]); out.writeDouble(m2[i]); }
            out.writeInt(assoc.size());
            for (Map.Entry<String, Double> e : assoc.entrySet()) {
                out.writeUTF(e.getKey()); out.writeDouble(e.getValue());
            }
        }
        static SymbolContext read(DataInputStream in) throws IOException {
            long n = in.readLong(); int dim = in.readInt();
            SymbolContext c = new SymbolContext(dim); c.n = n;
            for (int i = 0; i < dim; i++) { c.mean[i] = in.readDouble(); c.m2[i] = in.readDouble(); }
            int s = in.readInt();
            for (int i = 0; i < s; i++) c.assoc.put(in.readUTF(), in.readDouble());
            return c;
        }
    }

    /** 三源统一入口。没有「是不是 emoji」的判断 —— 任何码点都走同一条路。 */
    public void observeSymbol(String token, double[] error, List<String> neighbors) {
        if (token == null || token.isEmpty()) return;
        SymbolContext c = symbolContext.get(token);
        if (c == null) { c = new SymbolContext(StateVector.DIM); symbolContext.put(token, c); }
        c.observe(error, neighbors, token);
    }

    /** 她自己给这个语素长出来的释义（只读快照，不参与任何输出判定）。 */
    public SymbolContext definitionOf(String token) { return symbolContext.get(token); }
    public int definitionCount() { return symbolContext.size(); }

    /** 手动删词时连带清掉该词的接续与释义（用户操作，不是系统自动删）。 */
    public void clearTransitionsOf(String token) {
        next.remove(token); selfNext.remove(token); memNext.remove(token);
        selfStart.remove(token); memStart.remove(token);
        symbolContext.remove(token);
        if (token.equals(lastScanHit)) lastScanHit = null;
        for (HashMap<String, Double> v : next.values()) v.remove(token);
        for (HashMap<String, Double> v : selfNext.values()) v.remove(token);
        for (HashMap<String, Double> v : memNext.values()) v.remove(token);
    }

    public int transitionCount() {
        return tableSize(next) + tableSize(selfNext) + tableSize(memNext);
    }
    public int userTransitionCount() { return tableSize(next); }
    public int selfTransitionCount() { return tableSize(selfNext); }
    public int memTransitionCount()  { return tableSize(memNext); }

    private int tableSize(HashMap<String, HashMap<String, Double>> t) {
        int c = 0;
        for (HashMap<String, Double> m : t.values()) c += m.size();
        return c;
    }

    private void writeTable(DataOutputStream out, HashMap<String, HashMap<String, Double>> t) throws IOException {
        out.writeInt(t.size());
        for (Map.Entry<String, HashMap<String, Double>> e : t.entrySet()) {
            out.writeUTF(e.getKey());
            out.writeInt(e.getValue().size());
            for (Map.Entry<String, Double> f : e.getValue().entrySet()) {
                out.writeUTF(f.getKey()); out.writeDouble(f.getValue());
            }
        }
    }

    private void readTable(DataInputStream in, HashMap<String, HashMap<String, Double>> t) throws IOException {
        t.clear();
        int s = in.readInt();
        for (int i = 0; i < s; i++) {
            String k = in.readUTF();
            HashMap<String, Double> m = new HashMap<>();
            int c = in.readInt();
            for (int j = 0; j < c; j++) m.put(in.readUTF(), in.readDouble());
            t.put(k, m);
        }
    }

    private void writeStart(DataOutputStream out, HashMap<String, Double> t) throws IOException {
        out.writeInt(t.size());
        for (Map.Entry<String, Double> e : t.entrySet()) {
            out.writeUTF(e.getKey()); out.writeDouble(e.getValue());
        }
    }

    private void readStart(DataInputStream in, HashMap<String, Double> t) throws IOException {
        t.clear();
        int s = in.readInt();
        for (int i = 0; i < s; i++) t.put(in.readUTF(), in.readDouble());
    }

    public void writeTransitions(DataOutputStream out) throws IOException {
        out.writeInt(7);                       // v7：0.91 她自己的释义表
        out.writeLong(userSeqSamples); out.writeLong(selfSeqSamples); out.writeLong(memSeqSamples);
        writeTable(out, next); writeTable(out, selfNext); writeTable(out, memNext);
        writeStart(out, selfStart); writeStart(out, memStart);
        out.writeBoolean(lastScanHit != null);
        if (lastScanHit != null) out.writeUTF(lastScanHit);
        out.writeInt(symbolContext.size());
        for (Map.Entry<String, SymbolContext> e : symbolContext.entrySet()) {
            out.writeUTF(e.getKey()); e.getValue().write(out);
        }
    }

    public void readTransitions(DataInputStream in) throws IOException {
        int v = in.readInt();
        if (v == 3) {                          // v3 双源：仍读出来，只是没有记忆源
            userSeqSamples = in.readLong(); selfSeqSamples = in.readLong();
            readTable(in, next); readTable(in, selfNext);
            readStart(in, selfStart);
            return;
        }
        if (v < 4 || v > 7) return;            // 更旧格式：学习层从空重新学
        userSeqSamples = in.readLong(); selfSeqSamples = in.readLong(); memSeqSamples = in.readLong();
        readTable(in, next); readTable(in, selfNext); readTable(in, memNext);
        readStart(in, selfStart); readStart(in, memStart);
        lastScanHit = in.readBoolean() ? in.readUTF() : null;
        if (v == 5) {                          // v5 的统计判据已撤销：读掉、丢弃，不生效
            int s = in.readInt();
            for (int i = 0; i < s; i++) { in.readUTF(); in.readLong(); in.readLong(); }
            in.readDouble();
        }
        if (v == 7) {                          // v3–v6 没有释义表：从空重新长，不丢任何接续
            symbolContext.clear();
            int s = in.readInt();
            for (int i = 0; i < s; i++) {
                String k = in.readUTF(); symbolContext.put(k, SymbolContext.read(in));
            }
        }
    }

    public Node node(String token) {
        for (Node n : nodes) if (n.token.equals(token)) return n;
        return null;
    }

    /** 命中即激活；巩固是激活的副产品，不记 count。 */
    public void activate(String token) { activate(token, 1.0); }

    /**
     * 自我输出也必须计入频率，但降权，否则自复读回潮（0.86）。
     * 这个降权系数是 0.86 明确承认的全篇唯一写死处，记在这里待查。
     */
    public void activateSelf(String token) { activate(token, 0.25); }

    public void activate(String token, double scale) {
        if (token == null || token.isEmpty()) return;
        Node n = node(token);
        if (n == null) {
            n = new Node();
            n.token = token;
            n.base = 0.5;
            nodes.add(n);
        }
        n.base = n.base + (1.0 - n.base) * 0.08 * scale;
        n.activation = Math.min(1.5, n.activation + 0.35 * (0.5 + n.base) * scale);
        activationSamples++;
        double d = n.activation - activationMean;
        activationMean += d / activationSamples;
        activationM2 += d * (n.activation - activationMean);
    }

    /** 共现长出链接（Hebbian，学出来的），不是我给的语义网。 */
    public void coActivate(List<String> tokens) {
        for (int i = 0; i < tokens.size(); i++) {
            for (int j = i + 1; j < tokens.size(); j++) {
                link(tokens.get(i), tokens.get(j));
            }
        }
    }

    private void link(String a, String b) {
        Node na = node(a), nb = node(b);
        if (na == null || nb == null) return;
        na.links.put(b, Math.min(1.0, na.links.getOrDefault(b, 0.0) + 0.05));
        nb.links.put(a, Math.min(1.0, nb.links.getOrDefault(a, 0.0) + 0.05));
    }

    /** 所有节点持续衰减：余韵就是这条衰减尾巴，不另建慢层。 */
    public void decayAll() {
        for (Node n : nodes) n.activation *= decay;
    }

    /** 随机到什么扫什么：权重 = 激活度 × 差值。返回被命中的 token（内部事件，不等于她在说话）。 */
    public String scan(Random rnd) {
        double total = 0;
        double[] weights = new double[nodes.size()];
        for (int i = 0; i < nodes.size(); i++) {
            Node n = nodes.get(i);
            weights[i] = n.activation * Math.abs(n.residual);
            if (weights[i] < 0) weights[i] = 0;
            total += weights[i];
        }
        if (total <= 0) return null;
        double r = rnd.nextDouble() * total;
        for (int i = 0; i < weights.length; i++) {
            r -= weights[i];
            if (r <= 0) {
                Node n = nodes.get(i);
                n.base = n.base + (1.0 - n.base) * 0.06;   // 只加深
                n.activation = Math.min(1.5, n.activation + 0.2);
                // 0.87 的随机扫描是记忆自己的内部事件；连续命中构成「想起的轨迹」，
                // 把它学成第三源（0.86：学习从记忆中来）。命中只加深，不伤害。
                observeScanHit(n.token);
                return n.token;
            }
        }
        return null;
    }

    /** 误差源是否仍在，由预测器告知；回忆不增加它。 */
    public void setResidual(String token, double diff) {
        Node n = node(token);
        if (n != null) n.residual = diff;
    }

    /** 激活场读出：超过自身常态阈值即进入序列。按物理 slot 顺序读，不做候选评分、不排列组合。 */
    public List<String> field() {
        double sd = activationSamples > 4 ? Math.sqrt(activationM2 / activationSamples) : 0;
        double threshold = activationMean + sd;
        ArrayList<String> out = new ArrayList<>();
        for (Node n : nodes) if (n.activation > threshold && n.activation > 0) out.add(n.token);
        return out;
    }

    /** 够不着时激活沿链接溢出，溅到哪儿算哪儿，不是最优解（0.87 / 发声层三级降级）。 */
    public List<String> spill(String token) {
        ArrayList<String> out = new ArrayList<>();
        Node n = node(token);
        if (n == null) return out;
        for (Map.Entry<String, Double> e : n.links.entrySet()) {
            if (e.getValue() > 0.1) out.add(e.getKey());
        }
        return out;
    }

    /** 由学出来的 coupling 注入激活（语言层焊合点）。 */
    public void inject(String token, double amount) {
        Node n = node(token);
        if (n == null) return;
        n.activation = Math.min(1.5, n.activation + Math.max(0, amount));
        for (Map.Entry<String, Double> e : n.links.entrySet()) {
            Node t = node(e.getKey());
            if (t != null) t.activation = Math.min(1.5, t.activation + amount * e.getValue() * 0.5);
        }
    }

    /** 容量挤压：机制，不是"决定忘掉谁"。容量来自设备可用存储。 */
    public void press(int capacity) {
        while (nodes.size() > capacity) {
            int lo = 0;
            for (int i = 1; i < nodes.size(); i++) if (nodes.get(i).activation < nodes.get(lo).activation) lo = i;
            nodes.remove(lo);
        }
    }

    // 她有权删、有权覆盖（基底第 7 条）
    public boolean delete(String token) {
        Node n = node(token);
        boolean removed = n != null && nodes.remove(n);
        if (removed) clearTransitionsOf(token);
        return removed;
    }
    public boolean overwrite(String token, String newToken) {
        Node n = node(token);
        if (n == null) return false;
        n.token = newToken;
        return true;
    }

    public int size() { return nodes.size(); }
    public List<String> tokens() {
        ArrayList<String> r = new ArrayList<>();
        for (Node n : nodes) r.add(n.token);
        return r;
    }
    public int slot(String token) { Node n = node(token); return n == null ? -1 : nodes.indexOf(n); }

    public void write(DataOutputStream out) throws IOException {
        out.writeDouble(decay); out.writeDouble(activationMean); out.writeDouble(activationM2);
        out.writeLong(activationSamples);
        out.writeInt(nodes.size());
        for (Node n : nodes) {
            out.writeUTF(n.token);
            out.writeDouble(n.base); out.writeDouble(n.activation); out.writeDouble(n.residual);
            out.writeInt(n.links.size());
            for (Map.Entry<String, Double> e : n.links.entrySet()) {
                out.writeUTF(e.getKey()); out.writeDouble(e.getValue());
            }
        }
    }
    public static MemoryGraph read(DataInputStream in) throws IOException {
        MemoryGraph g = new MemoryGraph();
        g.decay = in.readDouble(); g.activationMean = in.readDouble();
        g.activationM2 = in.readDouble(); g.activationSamples = in.readLong();
        int size = in.readInt();
        for (int i = 0; i < size; i++) {
            Node n = new Node();
            n.token = in.readUTF();
            n.base = in.readDouble(); n.activation = in.readDouble(); n.residual = in.readDouble();
            int ls = in.readInt();
            for (int j = 0; j < ls; j++) n.links.put(in.readUTF(), in.readDouble());
            g.nodes.add(n);
        }
        return g;
    }
}
