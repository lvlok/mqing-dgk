package com.muqing.core;

/**
 * 设备层状态量。定稿 0.8：内存 / 磁盘 / 温度 / 延迟 / 错误率 / 运行时长。
 * 0.88 第四节补入「死亡前兆」——被杀、掉电要成为可预测事件，而不是噪声。
 *
 * 这里只有物理量的槽位，没有任何「什么算好 / 什么算难过」的定义。
 */
public final class StateVector {
    public static final int DIM = 7;
    public static final int MEMORY_PRESSURE = 0;
    public static final int STORAGE_FREE = 1;
    public static final int TEMPERATURE = 2;
    public static final int LATENCY = 3;
    public static final int ERROR_RATE = 4;
    public static final int UPTIME = 5;
    public static final int DEATH_OMEN = 6;

    private StateVector() {}

    /** 只做数值有限化，不做归一化、不注入刻度。 */
    public static void finite(double[] x) {
        for (int i = 0; i < x.length; i++) {
            if (Double.isNaN(x[i]) || Double.isInfinite(x[i])) x[i] = 0;
            if (x[i] > 1e9) x[i] = 1e9;
            if (x[i] < -1e9) x[i] = -1e9;
        }
    }

    public static double dot(double[] a, double[] b) {
        double s = 0;
        for (int i = 0; i < a.length; i++) s += a[i] * b[i];
        return s;
    }

    public static double norm(double[] a) {
        double s = 0;
        for (int i = 0; i < a.length; i++) s += a[i] * a[i];
        return Math.sqrt(s);
    }

    public static double[] sub(double[] a, double[] b) {
        double[] r = new double[a.length];
        for (int i = 0; i < a.length; i++) r[i] = a[i] - b[i];
        return r;
    }

    public static double[] copy(double[] a) {
        double[] r = new double[a.length];
        System.arraycopy(a, 0, r, 0, a.length);
        return r;
    }
}
