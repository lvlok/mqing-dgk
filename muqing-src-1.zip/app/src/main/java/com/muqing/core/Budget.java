package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * 不可逆预算（基底第 5 条 / 0.88 第四节）。
 *
 * 软件拿得到的电量、温度都会恢复 —— 遗留问题 3 承认这一点。
 * 真正不可逆的是：被杀、掉电、数据丢失、以及后果层日志的永久增长。
 * 所以这里把【已经发生的中断】与【日志写入】当作代价载体，
 * 而不是拿一个可逆量假装不可逆。
 *
 * 代价必须可预测才成为代价：死亡前兆进入设备层状态量，否则只是噪声。
 */
public final class Budget {
    private double irreversible;      // 累积的不可逆事件量
    private double pressure;          // 当前设备压力（可逆，仅作前兆）
    private long writes;

    public void recordInterruption() { irreversible += 1.0; }
    public void recordWrite() { writes++; irreversible += 0.004; }
    public void setPressure(double p) { pressure = p; }

    /** 一次表达的代价：不可逆痕迹 + 当前压力。没有我设定的"说话成本"。 */
    public double cost() { return 0.01 + irreversible * 0.002 + pressure * 0.05; }
    public double irreversible() { return irreversible; }
    public long writes() { return writes; }

    public void write(DataOutputStream out) throws IOException {
        out.writeDouble(irreversible); out.writeDouble(pressure); out.writeLong(writes);
    }
    public static Budget read(DataInputStream in) throws IOException {
        Budget b = new Budget();
        b.irreversible = in.readDouble(); b.pressure = in.readDouble(); b.writes = in.readLong();
        return b;
    }
}
