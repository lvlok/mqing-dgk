package com.muqing.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 后果层：append-only，她只能读，不能改；而对我，后果层【不用的】
 * —— 不纠正、不还原、不悄悄对齐（定稿 0.8）。
 *
 * 留档不当真相，只当"发生过"。why 恒为 null，不是克制，是字段从不被写入。
 */
public final class ConsequenceLog {
    public static final class Entry {
        public final long ts;
        public final String kind;
        public final String before;
        public final String after;
        public final String why;
        Entry(long ts, String kind, String before, String after) {
            this.ts = ts; this.kind = kind; this.before = before; this.after = after;
            this.why = null;                       // 第 7 条：故意留空，一直是空的
        }
        public String line() {
            return ts + "\t" + kind + "\t" + before + "\t" + after + "\tnull";
        }
    }

    private final ArrayList<Entry> entries = new ArrayList<>();

    public void append(String kind, String before, String after) {
        entries.add(new Entry(System.currentTimeMillis(), kind, before, after));
    }

    /** 只读视图。没有 remove / clear / edit —— append-only 是结构保证。 */
    public List<Entry> readOnly() { return Collections.unmodifiableList(entries); }

    public void restore(Entry e) { entries.add(e); }   // 仅供重启时读回，不产生新痕迹
}
