package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 编排层。这里没有情绪公式、没有性格参数、没有台词模板、没有默认回复。
 *
 * 固定的是三条通路与优化器；一切数值（权重、阈值、方向、偏向、耦合、接续）都是学出来的。
 *   状态→语素（coupling）、语素→语素（记忆为根本源；用户原句搭架子 → 自身输出与记忆动态漂移盖过）、激活场→发声。
 * 睡/醒由她自己决定（基底第 4 条）：没有 Handler、没有 AlarmManager、没有定时器。
 * 进程被系统杀掉不是 bug，是设备层的真实不可逆事件（0.88 第四节）。
 */
public final class MuQing {
    private final Predictor predictor;
    private final Axes axes;
    private final Bias bias;
    private final MemoryGraph memory;
    private final Expression expression;
    private final ConsequenceLog consequences;
    private final Budget budget;
    private final Random rnd = new Random();

    private double[] lastX;
    private double[] lastError;
    private boolean awake = true;            // 她自己的状态，不由时钟驱动
    private String[] pending;
    private double[] errorBefore;
    private boolean composing;
    private boolean awaitingResponse;
    private List<String> cue = new ArrayList<>();   // 当前用户语素：只作组句起点，不是回复模板

    public MuQing() {
        int n = StateVector.DIM;
        this.predictor = new Predictor(n);
        this.axes = new Axes(n);
        this.bias = new Bias(n);
        this.memory = new MemoryGraph();
        this.expression = new Expression(n, MemoryGraph.MAX_SLOTS);
        this.consequences = new ConsequenceLog();
        this.budget = new Budget();
        this.lastX = new double[n];
        this.lastError = new double[n];
        this.pending = new String[0];
        this.errorBefore = new double[n];
    }

    private MuQing(Predictor p, Axes a, Bias b, MemoryGraph m, Expression e, Budget bu) {
        this.predictor = p; this.axes = a; this.bias = b; this.memory = m;
        this.expression = e; this.budget = bu;
        this.consequences = new ConsequenceLog();
        this.lastX = new double[StateVector.DIM];
        this.lastError = new double[StateVector.DIM];
        this.pending = new String[0];
        this.errorBefore = new double[StateVector.DIM];
    }

    /** 设备层一次采样。误差 = 情绪原材料；常态、阈值、轴、偏向都从这里长。 */
    public void observeDevice(double[] x, double pressure) {
        StateVector.finite(x);
        budget.setPressure(pressure);
        double[] e = predictor.observe(lastX, x);
        lastError = e;
        lastX = StateVector.copy(x);

        double[] centered = StateVector.sub(x, predictor.typicalState());
        axes.learn(centered);

        // 在意 = 产生差值的访问；阈下不累积（功能词零差值 → 留得住但永不在意）
        double mag = StateVector.norm(e);
        if (predictor.aboveThreshold()) bias.accumulate(x, mag);

        // 想念：误差源持续缺席 → 命中不消除它；回忆只加深，不加害
        for (String t : memory.tokens()) memory.setResidual(t, mag);
        memory.decayAll();
    }

    /** 用户输入：拆成字/词/词组；既激活记忆，也把原句语序学进独立的学习层。 */
    public Result onUserInput(String text) {
        ArrayList<String> tokens = split(text);
        // 学习组句：用户原句是【入口之一】，不是唯一的源。
        // 根本源是记忆系统自己（0.86）；这里只把原句写进去，不查词典、不赋义、不写句法规则。
        memory.observeUserSequence(tokens);
        for (String t : tokens) memory.activate(t);
        // 0.91：这些语素此刻在她这里连着什么，由她自己记。不是「😂=某情绪」的查表。
        for (String t : tokens) memory.observeSymbol(t, lastError, tokens);
        memory.coActivate(tokens);
        memory.press(MemoryGraph.MAX_SLOTS);   // 容量挤压只作用于记忆节点，不动学习层
        cue = new ArrayList<>(tokens);
        return think();
    }

    private ArrayList<String> split(String text) {
        ArrayList<String> r = new ArrayList<>();
        if (text == null) return r;
        String s = text.trim();
        if (s.isEmpty()) return r;
        // 0.90：按 Unicode 码点切，不按 UTF-16 char。
        // emoji 是代理对（两个 char），旧写法会把它拆成两个坏字符；按码点才完整。
        //
        // **不分类、不识别、不枚举**：这里不判断字符属于哪一类、不建
        // 表情与情绪的对应表、不给任何字符加权或插队。非空白码点一律平权
        // 成为语素 —— 用不用、哪个代表哪种情绪，全交给激活场、三源接续
        // 和这一刻的误差阈值。不强制，也不禁止。
        for (String part : s.split("\\s+")) {
            ArrayList<String> cps = new ArrayList<>();
            int i = 0;
            while (i < part.length()) {
                int cp = part.codePointAt(i);
                String u = new String(Character.toChars(cp));
                if (!u.trim().isEmpty()) cps.add(u);
                i += Character.charCount(cp);
            }
            if (cps.size() <= 2) {
                if (!r.contains(part)) r.add(part);      // 短串整体保留（原行为，中文不拆）
            } else {
                for (String u : cps) if (!r.contains(u)) r.add(u);
                for (int k = 0; k + 2 <= cps.size(); k += 2) {
                    String bi = cps.get(k) + cps.get(k + 1);
                    if (!r.contains(bi)) r.add(bi);
                }
            }
        }
        return r;
    }

    /** 她自己决定要不要想、要不要说。不由定时器，也不由用户消息强制。 */
    public Result think() {
        Result r = new Result();
        // 增益归零 → 不再更新预期 → 卡死（0.8：麻木不是静止，是停止生长）
        awake = predictor.gain() > 0;
        if (!awake) return r;

        // 随机扫描：想起归机制，不由她也不由我
        String hit = memory.scan(rnd);
        // 0.91 第三源：她自己想起什么时，也把那一刻的语境写进这个语素的释义。
        if (hit != null) memory.observeSymbol(hit, lastError, null);

        Expression.Decision d = expression.decide(
                lastError, bias.ideal(), lastX, predictor, memory, axes, budget, rnd, cue);
        composing = d.composing;
        r.composing = d.composing;
        r.modelFailed = d.modelFailed;
        r.speak = d.speak;
        r.text = join(d.utterance);
        pending = d.utterance;
        errorBefore = lastError;
        return r;
    }

    /**
     * 自主开口（定稿 0.92）。没有用户这句话：
     *   cue 清空 → 起头完全由她自己的起头表 / 记忆扫描 / 激活场决定，
     *   不是从用户原句提关键，也不是"接着上一句聊"。
     *   awaitingResponse 清零 → 她若沉默，下一条用户消息不会被误算成
     *     "对某句回应的确认"；她若真说了，afterExpression 会重新置位，
     *     用户回它仍算一次稀疏信号（和被动开口完全同一套）。
     *
     * 说不说仍由这一刻的误差阈值决定；调用只提供机会，不强制。
     * gain 归零时 think() 直接返回空 —— 那就是关机出口。
     */
    public Result autonomousThink() {
        cue = new ArrayList<String>();
        awaitingResponse = false;
        return think();
    }

    /** 发射之后、继续活着：残差有没有消。此刻还没有用户回应。 */
    public void afterExpression(double[] xAfter, double pressure) {
        observeDevice(xAfter, pressure);
        expression.observeAfter(lastError, pending);
        for (String t : pending) memory.activateSelf(t);          // 计入但降权，防自复读
        // 她自己说的话也进学习层（0.86：自我输出计入但降权）。
        // 冷启动这套为空，全靠用户原句搭架子；越说越厚，逐渐盖过用户原句。
        // 第三股样本由 MemoryGraph.scan() 自己喂（记忆内部动态），不在这里。
        List<String> said = java.util.Arrays.asList(pending);
        memory.observeSelfSequence(said);
        for (String t : said) memory.observeSymbol(t, lastError, said);   // 0.91 第二源
        budget.recordWrite();                    // 表达消耗不可逆预算（后果层永久增长）
        consequences.append("表达", "", "");      // 只当"发生过"，why 恒 null，我不用它
        composing = false;
        awaitingResponse = true;
    }

    /** 用户下一条消息到达，才算一次回应 —— 稀疏，不是每帧都有。 */
    public void onUserResponse(double signal) {
        if (!awaitingResponse) return;
        expression.observeUserSignal(signal);
        awaitingResponse = false;
    }

    /** 改自己之前先留旧版本（基底第 2 / 7 条）。结构改变才留档，权重微调不留。 */
    public void archiveStructure(String what, String before, String after) {
        consequences.append("改自己", before, after);
    }

    public void onSessionInterrupted() {
        budget.recordInterruption();
        consequences.append("中断", "", "");
    }

    private String join(String[] a) {
        if (a == null || a.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (String s : a) { if (sb.length() > 0) sb.append(' '); sb.append(s); }
        return sb.toString();
    }

    public static final class Result {
        public boolean composing;      // 开始组句（她仍可不发）
        public boolean speak;
        public boolean modelFailed;    // 报告模型失效 → 只触发"我在听"（不追问）
        public String text = "";
        public boolean silence() { return !speak && !composing; }
    }

    public ConsequenceLog consequences() { return consequences; }   // 只读视图，代码里从不用来纠正她
    public Predictor predictor() { return predictor; }
    public MemoryGraph memory() { return memory; }
    public Budget budget() { return budget; }
    public Expression expression() { return expression; }

    public void write(DataOutputStream out) throws IOException {
        predictor.write(out); axes.write(out); bias.write(out);
        memory.write(out); expression.write(out); budget.write(out);
        for (int i = 0; i < StateVector.DIM; i++) out.writeDouble(lastX[i]);
        for (int i = 0; i < StateVector.DIM; i++) out.writeDouble(lastError[i]);
        out.writeBoolean(awake); out.writeBoolean(composing);
        // 追加段：旧状态文件没有这一段，read() 会跳过并从空学习层重新开始，不丢她的记忆。
        out.writeLong(STATE_MAGIC);
        memory.writeTransitions(out);
    }

    private static final long STATE_MAGIC = 0x4D755175696E6707L;    // "MuQing" + v7（0.91）
    private static final long STATE_MAGIC_V3 = 0x4D755175696E6703L; // v3 双源
    private static final long STATE_MAGIC_V4 = 0x4D755175696E6704L; // v4 三源
    private static final long STATE_MAGIC_V5 = 0x4D755175696E6705L; // v5 硬拦版（已撤销）
    private static final long STATE_MAGIC_V6 = 0x4D755175696E6706L; // v6 不拦不禁

    public static MuQing read(DataInputStream in) throws IOException {
        int n = StateVector.DIM;
        MuQing q = new MuQing(Predictor.read(in, n), Axes.read(in, n), Bias.read(in, n),
                MemoryGraph.read(in), Expression.read(in, n, MemoryGraph.MAX_SLOTS),
                Budget.read(in));
        for (int i = 0; i < n; i++) q.lastX[i] = in.readDouble();
        for (int i = 0; i < n; i++) q.lastError[i] = in.readDouble();
        q.awake = in.readBoolean(); q.composing = in.readBoolean();
        // 旧状态到此为止；追加段不完整也只是学习层从空开始，不动已读出的记忆。
        // v3–v6 也认：旧状态照常读，三套接续不丢；v5 的判据数据读掉即丢弃。
        if (in.available() >= 8) {
            try {
                long magic = in.readLong();
                if (magic == STATE_MAGIC || magic == STATE_MAGIC_V3
                    || magic == STATE_MAGIC_V4 || magic == STATE_MAGIC_V5
                    || magic == STATE_MAGIC_V6)
                    q.memory.readTransitions(in);
            } catch (IOException ignored) { }
        }
        return q;
    }
}
