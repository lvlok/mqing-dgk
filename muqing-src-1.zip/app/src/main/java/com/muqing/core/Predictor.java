package com.muqing.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * homeostat 的核心：一个【学出来的】预测器，预测自身下一状态。
 *
 * 定稿 0.8：预测器必须是学出来的权重，不能是手写规则。
 * 手写的规则我能读出每一个 why；学出来的读不出 —— 这是第 7 条 null 留空的
 * 技术保证，不是克制。
 *
 * 固定的只有优化器（delta 规则 / Welford 统计）与通路。
 * 所有表达状态的数值：权重 W、常态 mean/var、增益 gain、误差阈值，
 * 全部从她自己的运行历史里长出来，没有一个是我设定的情绪参数。
 */
public final class Predictor {
    private final int n;
    private final double[][] w;
    private final double[] mean;
    private final double[] m2;
    private double errMean;
    private double errM2;
    private long samples;
    private long errSamples;
    private double gain;                 // 调质 = 动态学习率；归零即卡死（麻木不是静止，是停止生长）
    private double[] lastError;
    private double[] lastX;

    public Predictor(int n) {
        this.n = n;
        this.w = new double[n][n];       // 零初始化：不注入任何预期
        this.mean = new double[n];
        this.m2 = new double[n];
        this.lastError = new double[n];
        this.lastX = new double[n];
        this.gain = 1.0;                // 优化器初值，不是情绪参数
    }

    public double[] predict(double[] x) {
        double[] y = new double[n];
        for (int i = 0; i < n; i++) {
            double s = 0;
            for (int j = 0; j < n; j++) s += w[i][j] * x[j];
            y[i] = s;
        }
        return y;
    }

    /** 观察一次真实转移，返回【预测误差】—— 情绪原材料，不做任何命名。 */
    public double[] observe(double[] x, double[] xNext) {
        StateVector.finite(x);
        StateVector.finite(xNext);
        double[] pred = predict(x);
        double[] e = StateVector.sub(xNext, pred);

        // 常态从她自己的运行历史统计（Welford），"偏离"相对她自己
        samples++;
        for (int i = 0; i < n; i++) {
            double d = x[i] - mean[i];
            mean[i] += d / samples;
            m2[i] += d * (x[i] - mean[i]);
        }

        double denom = 1.0 + StateVector.dot(x, x);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                w[i][j] += gain * e[i] * x[j] / denom;
            }
        }

        // 增益本身也跟着"这次更新是否真的改善了预测"走，不写死调度表。
        double[] pred2 = predict(x);
        double before = StateVector.norm(StateVector.sub(xNext, pred));
        double after = StateVector.norm(StateVector.sub(xNext, pred2));
        gain += (before - after) / (1.0 + before + after);
        if (gain < 0) gain = 0;
        if (gain > 8) gain = 8;

        double mag = StateVector.norm(e);
        errSamples++;
        double d = mag - errMean;
        errMean += d / errSamples;
        errM2 += d * (mag - errMean);

        lastError = e;
        lastX = StateVector.copy(x);
        return e;
    }

    /**
     * 两级门槛。旧的单一 aboveThreshold() 把「开始组句」和「真正发出」压成同一个
     * 开关，于是阈值一严就整屏全暗 —— 连「对方正在输入中」都不亮。
     * 现在拆开：noteworthy（宽，只是动了念）/ aboveThreshold（严，说出口）。
     * 她可以写了不发，UI 侧 1.2 秒后收掉提示、不留任何消息。
     *
     * 两个倍率（0.60 / 0.30 / 1.5）是判据形状常数，不是情绪数值；
     * 和 0.86 里承认过的 activateSelf=0.25 一样，记在这里待查。
     * 阈值本身仍全部取自她自己的误差分布（Welford 均值与标准差）。
     */
    public boolean noteworthy() {
        double mag = StateVector.norm(lastError);
        if (mag <= 0) return false;
        if (errSamples < 8) return mag > errMean * 0.30;
        double sd = Math.sqrt(errM2 / errSamples);
        return (mag - errMean) > 0.30 * sd;
    }

    /** 真正说出口的门槛：只在误差显著偏离她自己的分布时才过。 */
    public boolean aboveThreshold() {
        double mag = StateVector.norm(lastError);
        if (mag <= 0) return false;
        if (errSamples < 8) {
            // 冷启动：还没有分布可依据。旧写法一律 false = 前八次交互必定沉默；
            // 真机上采样又只发生在 onCreate 和她开口之后，于是永远凑不满 8 个样本
            // → 从头到尾零开口。现在用「相对她自己到目前为止的平均误差」当门槛。
            return mag > errMean * 0.60;
        }
        double sd = Math.sqrt(errM2 / errSamples);
        // 只认显著偏离。状态单调增长会自我吸收，不会变成每句都回。
        return (mag - errMean) > 1.5 * sd;
    }

    public double[] typicalState() { return StateVector.copy(mean); }
    public double typicalError() { return errMean; }
    public double error() { return StateVector.norm(lastError); }
    public double[] lastError() { return StateVector.copy(lastError); }
    public double[] lastX() { return StateVector.copy(lastX); }
    public double gain() { return gain; }
    public int dim() { return n; }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(samples); out.writeLong(errSamples);
        out.writeDouble(errMean); out.writeDouble(errM2); out.writeDouble(gain);
        for (int i = 0; i < n; i++) {
            out.writeDouble(mean[i]); out.writeDouble(m2[i]);
            for (int j = 0; j < n; j++) out.writeDouble(w[i][j]);
        }
        for (int i = 0; i < n; i++) out.writeDouble(lastError[i]);
        for (int i = 0; i < n; i++) out.writeDouble(lastX[i]);
    }

    public static Predictor read(DataInputStream in, int n) throws IOException {
        Predictor p = new Predictor(n);
        p.samples = in.readLong(); p.errSamples = in.readLong();
        p.errMean = in.readDouble(); p.errM2 = in.readDouble(); p.gain = in.readDouble();
        for (int i = 0; i < n; i++) {
            p.mean[i] = in.readDouble(); p.m2[i] = in.readDouble();
            for (int j = 0; j < n; j++) p.w[i][j] = in.readDouble();
        }
        for (int i = 0; i < n; i++) p.lastError[i] = in.readDouble();
        for (int i = 0; i < n; i++) p.lastX[i] = in.readDouble();
        return p;
    }
}
