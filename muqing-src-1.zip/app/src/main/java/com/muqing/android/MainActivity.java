package com.muqing.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.muqing.R;
import com.muqing.core.MuQing;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 聊天主界面。
 *
 * 顶栏：头像 + AI 名字 + ☰，三者同一高度。
 * 她开始组句时名字向上移一点，名字下方出现小字「对方正在输入中」。
 * 【整个聊天界面不显示任何类似思考过程的界面或文字】——
 * 没有"思考中""正在想""生成中""她正在…"，只有这一个输入指示，
 * 而且它由"开始组句"这个动作触发，不是状态报告。
 *
 * 从左往右划弹出列表（dx > 120）。软键盘弹出时窗口可用高度变小，
 * 整个根布局压缩到键盘上方（adjustResize，不是 adjustPan）。
 *
 * 清理模式：列表里点「清理聊天数据」回到这里，点选气泡 → 点「清理」。
 * 只删 chat.log 的表面记录，不碰 muqing.state / consequence.log。
 */
public final class MainActivity extends Activity {
    private MuQing q;
    private Store store;
    private DeviceProbe probe;
    private UiPrefs prefs;
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText input;
    private TextView title;
    private TextView typing;
    private ImageView avatar;
    private View root;
    private View btnSettings;
    private View inputBar;
    private View cleanupBar;

    private float downX, downY;
    private int lastVisibleHeight;

    private boolean cleanupMode;
    private int composingSeq;
    private final Set<Integer> selected = new HashSet<Integer>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        prefs = new UiPrefs(this);
        root = findViewById(R.id.root);
        chat = findViewById(R.id.chat);
        scroll = findViewById(R.id.scroll);
        input = findViewById(R.id.input);
        title = findViewById(R.id.title);
        typing = findViewById(R.id.typing);
        avatar = findViewById(R.id.avatar);
        btnSettings = findViewById(R.id.btn_settings);
        inputBar = findViewById(R.id.input_bar);
        cleanupBar = findViewById(R.id.cleanup_bar);

        store = new Store(this);
        probe = new DeviceProbe(this);
        q = store.load();

        boolean interrupted = store.wasInterrupted();
        store.markAlive();
        if (interrupted) q.onSessionInterrupted();     // 被杀/掉电：真实不可逆代价

        double[] x = probe.sample();
        // 0.92：打开界面也是一次"被唤醒的机会"。复用同一次采样，
        // 不二次采样把 LATENCY 抹平；说不说仍由她这一刻的阈值决定。
        if (prefs.autonomousAllowed()) {
            Autonomous.tick(this, q, store, probe, x);
        } else {
            q.observeDevice(x, probe.pressure(x));
            store.save(q);
            Autonomous.disarm(this);
        }

        ((Button) findViewById(R.id.send)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { send(); }
        });
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int id, android.view.KeyEvent e) {
                send(); return true;
            }
        });
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openList(); }
        });
        ((Button) findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { exitCleanup(); }
        });
        ((Button) findViewById(R.id.btn_cleanup)).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                store.deleteChatLines(selected);       // 只动 chat.log
                selected.clear();
                exitCleanup();
            }
        });

        attachKeyboardWatch();
        handleIntent(getIntent());   // 内部已 renderChat
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i != null && i.getBooleanExtra("enter_cleanup", false)) enterCleanup();
        else exitCleanup();
    }

    @Override protected void onResume() {
        super.onResume();
        applyUi();
        scrollToEnd();
    }

    /** 清理模式：输入栏换成操作条，气泡可点选。不显示任何"思考过程"。 */
    private void enterCleanup() {
        cleanupMode = true;
        selected.clear();
        inputBar.setVisibility(View.GONE);
        cleanupBar.setVisibility(View.VISIBLE);
        btnSettings.setVisibility(View.GONE);
        typing.setVisibility(View.GONE);
        title.setTranslationY(0);
        renderChat();
    }

    private void exitCleanup() {
        cleanupMode = false;
        selected.clear();
        inputBar.setVisibility(View.VISIBLE);
        cleanupBar.setVisibility(View.GONE);
        btnSettings.setVisibility(View.VISIBLE);
        renderChat();
    }

    /** 从左往右划弹出列表。用 dispatchTouchEvent 而不拦截子 view 的点击。 */
    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (cleanupMode) return super.dispatchTouchEvent(ev);
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            downX = ev.getX(); downY = ev.getY();
        } else if (ev.getAction() == MotionEvent.ACTION_UP) {
            float dx = ev.getX() - downX;
            float dy = ev.getY() - downY;
            if (dx > 120 && dx > Math.abs(dy) * 1.5f) {
                openList();
                return true;
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    private void openList() {
        startActivity(new Intent(MainActivity.this, SettingsActivity.class));
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_stay);
    }

    private void attachKeyboardWatch() {
        final View decor = getWindow().getDecorView();
        final android.graphics.Rect r = new android.graphics.Rect();
        decor.getViewTreeObserver().addOnGlobalLayoutListener(
                new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
            @Override public void onGlobalLayout() {
                decor.getWindowVisibleDisplayFrame(r);
                int visible = r.height();
                if (visible <= 0) return;
                if (visible != lastVisibleHeight) {
                    lastVisibleHeight = visible;      // 键盘弹起 / 收起
                    scrollToEnd();
                    scroll.postDelayed(new Runnable() {
                        @Override public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
                    }, 220);
                }
            }
        });
    }

    private void applyUi() {
        title.setText(prefs.name());
        avatar.setImageBitmap(avatarBitmap(ImagePick.AVATAR_AI, prefs.hasAvatarAi()));
        if (prefs.hasBg()) {
            File f = ImagePick.file(this, ImagePick.BG);
            if (f.exists()) {
                Drawable d = Drawable.createFromPath(f.getPath());
                if (d != null) { root.setBackground(d); return; }
            }
        }
        root.setBackgroundResource(R.drawable.black);
    }

    private Bitmap avatarBitmap(String name, boolean custom) {
        if (custom) {
            File f = ImagePick.file(this, name);
            if (f.exists()) {
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                if (b != null) return b;
            }
        }
        return BitmapFactory.decodeResource(getResources(), R.drawable.black);
    }

    private void send() {
        if (cleanupMode) return;
        String text = input.getText().toString();
        if (TextUtils.isEmpty(text)) return;
        input.setText("");
        q.onUserResponse(1.0);          // 上一句是否得到回应，到这里才知道（稀疏）
        store.appendChat(text, true);
        renderChat();

        // 用户消息到达 = 一次真实的设备事件，设备层必须在此采样。
        // 之前只在 onCreate 和她开口后的 afterExpression 里采样：
        // 她不开口 → 不再采样 → 误差冻结 → 阈值永假 → 更不开口（死锁闭环）。
        // 这不是定时器，不驱动她说话，只是让状态量跟着真实事件往前走。
        double[] x = probe.sample();
        q.observeDevice(x, probe.pressure(x));

        MuQing.Result r = q.onUserInput(text);
        setComposing(r.composing);

        if (r.speak) {
            store.appendChat(r.text, false);
            renderChat();
            setComposing(false);
            double[] after = probe.sample();
            q.afterExpression(after, probe.pressure(after));
        } else if (r.composing) {
            // 她可以不发。提示随后消失，且不留任何消息。
            final int seq = composingSeq;
            typing.postDelayed(new Runnable() {
                @Override public void run() {
                    if (seq == composingSeq && !cleanupMode) setComposing(false);
                }
            }, 1200);
        }
        scrollToEnd();
        scroll.postDelayed(new Runnable() {
            @Override public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
        }, 220);
        store.save(q);
    }

    /** 她开始组句 → 名字上移一点、下方出小字。不显示任何思考过程。 */
    private void setComposing(boolean on) {
        composingSeq++;
        if (cleanupMode) { typing.setVisibility(View.GONE); title.setTranslationY(0); return; }
        typing.setVisibility(on ? View.VISIBLE : View.GONE);
        title.setTranslationY(on ? -8 : 0);
    }

    private void scrollToEnd() {
        scroll.post(new Runnable() {
            @Override public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
        });
    }

    private void renderChat() {
        chat.removeAllViews();
        List<Store.ChatLine> lines = store.readChat();
        long[] ats = new long[lines.size()];
        for (int i = 0; i < lines.size(); i++) ats[i] = lines.get(i).at;
        boolean[] marks = ChatStamps.marks(ats);
        long now = System.currentTimeMillis();
        for (int i = 0; i < lines.size(); i++) {
            // 时间戳是聊天流里独立的一行，不在气泡里、不挂角标、不占消息索引。
            // 清理模式按 chat.log 行号选中，插入行不参与，所以选中关系不变。
            if (marks[i]) stamp(ChatStamps.text(ats[i], now));
            bubble(lines.get(i).text, lines.get(i).user, i);
        }
        scrollToEnd();
    }

    /** 独立的一行时间，居中、小字、无背景、不可点选。不属于任何气泡。 */
    private void stamp(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setTextColor(0xFF9AA3B5);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 14, 0, 10);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        t.setLayoutParams(lp);
        chat.addView(t);
    }

    /** 一条消息 = 头像 + 气泡。清理模式下整行可点选（半透明高亮）。 */
    private void bubble(String text, boolean user, final int index) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(12, 6, 12, 6);

        ImageView av = new ImageView(this);
        av.setScaleType(ImageView.ScaleType.CENTER_CROP);
        av.setImageBitmap(avatarBitmap(user ? ImagePick.AVATAR_USER : ImagePick.AVATAR_AI,
                user ? prefs.hasAvatarUser() : prefs.hasAvatarAi()));
        av.setBackgroundResource(R.drawable.bg_avatar_circle);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(72, 72);
        ap.setMargins(user ? 8 : 0, 0, user ? 0 : 8, 0);
        av.setLayoutParams(ap);

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(15);
        tv.setTextColor(user ? prefs.textUser() : prefs.textAi());
        tv.setPadding(24, 16, 24, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = user ? Gravity.END : Gravity.START;
        tv.setLayoutParams(lp);
        applyBubble(tv, user);

        if (user) { row.addView(tv); row.addView(av); }
        else { row.addView(av); row.addView(tv); }

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(user ? Gravity.END : Gravity.START);
        wrap.addView(row);

        if (cleanupMode) {
            wrap.setBackgroundColor(selected.contains(index) ? 0x44FF6B81 : 0x00000000);
            row.setAlpha(selected.contains(index) ? 0.45f : 1.0f);
            wrap.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (selected.contains(index)) selected.remove(index);
                    else selected.add(index);
                    renderChat();
                }
            });
        }
        chat.addView(wrap);
    }

    /** 气泡：用户上传的单一图片或 GIF 优先；没有就用各自的气泡颜色。
     *  文字颜色始终生效（上传图片时也一样）。 */
    private void applyBubble(TextView tv, boolean user) {
        if (prefs.hasBubble()) {
            File f = ImagePick.file(this, ImagePick.BUBBLE);
            if (f.exists()) {
                BubbleDrawable d = BubbleDrawable.from(f.getPath(), ImagePick.isGif(f));
                if (d != null) { tv.setBackground(d); return; }
            }
        }
        GradientDrawable g = new GradientDrawable();
        g.setColor(user ? prefs.bubbleUser() : prefs.bubbleAi());
        g.setCornerRadius(28);
        tv.setBackground(g);
    }

    @Override protected void onDestroy() {
        store.save(q);
        store.markCleanExit();
        super.onDestroy();
    }
}
