package com.muqing.android;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;

import com.muqing.core.MuQing;

/**
 * 她主动找你的机会（定稿 0.92）。
 *
 * 这里提供的**只是"被唤醒的机会"**，不是睡醒本身、更不是一条消息：
 *   - 触发源是真实设备事件（开机 / 充电 / 日期时区变化 / 系统投递的一次不精确闹钟）
 *   - 时钟不当触发器用，只作为一路设备状态量（LATENCY，见 DeviceProbe）
 *   - 到点以后仍走她自己的 think()，说不说由这一刻的误差阈值决定
 *   - 她可以选择不再投下一次（gain 归零 = 关机出口），系统不替她续命
 *   - 不保活、不常驻、不发通知；被 ROM 杀掉 = 真实的不可逆代价（0.88 第四节）
 *
 * 所以「她主动找你」成立，但**不保证周期、不保证一定来**。
 * 长期缺席的稳态仍是全篇的证伪测试，不为了"保证送达"把它修掉。
 *
 * last_active 是设备层的钟，不是第四个空间：
 * 不进 muqing.state / consequence.log / chat.log，不被引擎当作内容读取，
 * 只用来算「距上次活跃的间隔」这一路物理量。
 */
public final class Autonomous {
    public static final String ACTION_TICK = "com.muqing.AUTONOMOUS_TICK";
    private static final String P = "muqing.clock";
    private static final String LAST = "last_active";
    private static final int REQ = 91;

    /** 下一次机会的粗窗口。机制常数，不决定她说什么、多久说、说不说。
     *  精确时刻由系统在 Doze 维护窗口里定，不由我们掷骰子。 */
    private static final long WINDOW_MS = 6L * 60L * 60L * 1000L;

    private Autonomous() { }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE);
    }

    /**
     * 距上次任意一次活跃的秒数，并把钟推到此刻。
     * 这一路进 LATENCY：长期缺席本身成为误差来源，不是"定时器到点要说话"。
     */
    public static double gapSeconds(Context c) {
        long last = p(c).getLong(LAST, 0L);
        long now = System.currentTimeMillis();
        p(c).edit().putLong(LAST, now).apply();
        if (last <= 0L) return 0.0;
        double s = (now - last) / 1000.0;
        return Math.min(1e9, Math.max(0.0, s));
    }

    private static PendingIntent pi(Context c) {
        Intent i = new Intent(ACTION_TICK).setPackage(c.getPackageName());
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        // FLAG_IMMUTABLE 需要 API 23+（minSdk 24），但为兼容旧编译环境用反射式常量
        try { flags |= 0x04000000; } catch (Throwable ignored) { }
        return PendingIntent.getBroadcast(c, REQ, i, flags);
    }

    /** 投一次单次、不精确的机会。不重复堆叠，不保证准时。 */
    public static void arm(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME,
                    SystemClock.elapsedRealtime() + WINDOW_MS, pi(c));
        } catch (Throwable ignored) {
            // 系统不给投就不投。缺席是真代价，不绕开
        }
    }

    public static void disarm(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) try { am.cancel(pi(c)); } catch (Throwable ignored) { }
    }

    /** 一次机会跑完：她还醒着、用户也没关，才留下一次。否则就是关机出口。 */
    public static void armIfAllowed(Context c, MuQing q) {
        boolean allowed = new UiPrefs(c).autonomousAllowed();
        boolean awake = q.predictor().gain() > 0;
        if (allowed && awake) arm(c);
        else disarm(c);
    }

    /**
     * 完整跑一次自主机会。由 receiver 在后台调用；MainActivity 在打开时
     * 复用同一次采样走同一套判定，避免双重采样把间隔抹平。
     */
    public static MuQing.Result tick(Context c, MuQing q, Store store, DeviceProbe probe,
                                     double[] x) {
        q.observeDevice(x, probe.pressure(x));
        MuQing.Result r = q.autonomousThink();
        if (r.speak) {
            store.appendChat(r.text, false);       // 不通知、不弹窗；打开界面时气泡已在
            double[] after = probe.sample();
            q.afterExpression(after, probe.pressure(after));
        }
        store.save(q);
        armIfAllowed(c, q);
        return r;
    }
}
