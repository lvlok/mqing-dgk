package com.muqing.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 真实设备事件唤醒（定稿 0.92）。
 *
 * 静态注册的只有 Android 8+ 豁免广播与自家 alarm：
 *   开机 / 应用被替换 / 时间被改 / 时区 / 日期 / 语言 / 插拔电源 / 一次不精确机会
 * 没有 Service、没有前台保活、没有轮询、没有通知。
 *
 * 每次投递只是"给她一次机会"：真正说不说走 MuQing.autonomousThink()。
 * 她能在 gain 归零时不再投下一次 —— 那是关机出口，不是失败。
 */
public final class AutonomousReceiver extends BroadcastReceiver {
    @Override public void onReceive(final Context ctx, final Intent intent) {
        if (!new UiPrefs(ctx).autonomousAllowed()) return;
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Context c = ctx.getApplicationContext();
                    Store store = new Store(c);
                    DeviceProbe probe = new DeviceProbe(c);
                    com.muqing.core.MuQing q = store.load();
                    double[] x = probe.sample();
                    Autonomous.tick(c, q, store, probe, x);
                    // 注意：不碰 alive。它标记的是"上次会话有没有被杀"，
                    // 后台机会不是一次会话，动了会把被杀误判成正常退出。
                } catch (Throwable ignored) {
                    // 后台机会失败也只是缺席，不重试、不补发
                } finally {
                    pr.finish();
                }
            }
        }, "muqing-autonomous").start();
    }
}
