package com.muqing.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/**
 * 界面偏好：名字 / 双方头像 / 聊天背景 / 气泡图 / 双方气泡与文字颜色。
 *
 * 默认：双方头像与聊天背景都是同一张全黑图（black.png）；
 * 用户气泡蓝底白字、她灰底深字（黑背景下能看清）。
 *
 * 这些全是静态锚，不携带"她现在怎样"，不进她的内部，因此不破「透明」。
 */
public final class UiPrefs {
    private static final String P = "muqing.ui";
    public static final String DEFAULT_NAME = "沐晴";

    public static final int DEF_BUBBLE_USER = 0xFF0084FF;
    public static final int DEF_TEXT_USER = 0xFFFFFFFF;
    public static final int DEF_BUBBLE_AI = 0xFFE8E8E8;
    public static final int DEF_TEXT_AI = 0xFF222222;

    private final SharedPreferences p;

    public UiPrefs(Context c) { p = c.getSharedPreferences(P, Context.MODE_PRIVATE); }

    public String name() { return p.getString("name", DEFAULT_NAME); }
    public void name(String s) { p.edit().putString("name", s).apply(); }

    /** 档案九条第 7 条「可自主给用户发消息（可关）」。默认开，用户可关。
     *  关掉 = 撤掉后台机会，打开界面时也不再自主开口；只剩用户先说话这条路。 */
    public boolean autonomousAllowed() { return p.getBoolean("autonomous", true); }
    public void autonomousAllowed(boolean b) { p.edit().putBoolean("autonomous", b).apply(); }

    public boolean hasAvatarAi() { return p.getBoolean("avatar_ai", false); }
    public void hasAvatarAi(boolean b) { p.edit().putBoolean("avatar_ai", b).apply(); }

    public boolean hasAvatarUser() { return p.getBoolean("avatar_user", false); }
    public void hasAvatarUser(boolean b) { p.edit().putBoolean("avatar_user", b).apply(); }

    public boolean hasBg() { return p.getBoolean("bg", false); }
    public void hasBg(boolean b) { p.edit().putBoolean("bg", b).apply(); }

    public boolean hasBubble() { return p.getBoolean("bubble", false); }
    public void hasBubble(boolean b) { p.edit().putBoolean("bubble", b).apply(); }

    // 气泡和颜色：分别改用户 / AI 的气泡底色与文字颜色
    public int bubbleUser() { return p.getInt("bubble_user", DEF_BUBBLE_USER); }
    public void bubbleUser(int c) { p.edit().putInt("bubble_user", c).apply(); }
    public int textUser() { return p.getInt("text_user", DEF_TEXT_USER); }
    public void textUser(int c) { p.edit().putInt("text_user", c).apply(); }
    public int bubbleAi() { return p.getInt("bubble_ai", DEF_BUBBLE_AI); }
    public void bubbleAi(int c) { p.edit().putInt("bubble_ai", c).apply(); }
    public int textAi() { return p.getInt("text_ai", DEF_TEXT_AI); }
    public void textAi(int c) { p.edit().putInt("text_ai", c).apply(); }

    /** 恢复全部默认 = 全黑 + 默认配色。不删用户上传的文件，只把开关拨回默认。 */
    public void resetAll() { p.edit().clear().apply(); }

    public static int parseHex(String s, int fallback) {
        if (s == null) return fallback;
        String t = s.trim();
        if (t.length() == 6) t = "#" + t;
        try { return Color.parseColor(t); } catch (Exception e) { return fallback; }
    }

    public static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }
}
