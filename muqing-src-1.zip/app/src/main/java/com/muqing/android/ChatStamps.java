package com.muqing.android;

/**
 * 聊天时间戳的**纯计算**。不依赖 Android，也不进她的内部。
 *
 * 属表面类型层（chat.log 的显示锚），和名字 / 头像 / 气泡颜色一样：
 *   - 不写 muqing.state，不写 consequence.log
 *   - 不被引擎读回、不参与学习、不改阈值、不决定说不说
 *   - 不是触发器：不排班、不调度、不启动任何定时器（0.92 三、四）
 *
 * 时钟在这里只用来把「说过的话」标在界面上，与设备层 LATENCY 是两回事。
 *
 * 口径：**距上一次已打印的时间戳 ≥ 3 分钟，就重新打印一次**；首条有时间的
 * 消息前必打。旧记录没有时间就留空，不倒推、不补写、不假造痕迹。
 */
public final class ChatStamps {
    public static final long GAP_MS = 3L * 60L * 1000L;

    private ChatStamps() { }

    /**
     * 返回与消息等长的标记：该条消息**前面**是否插入一行独立的时间戳。
     * at[i] < 0 表示该条是旧记录、没有时间，跳过且不改变锚点。
     */
    public static boolean[] marks(long[] at) {
        boolean[] m = new boolean[at.length];
        boolean shown = false;
        long anchor = Long.MIN_VALUE;
        for (int i = 0; i < at.length; i++) {
            if (at[i] < 0) continue;
            if (!shown || at[i] - anchor >= GAP_MS) {
                m[i] = true;
                shown = true;
                anchor = at[i];
            }
        }
        return m;
    }

    /** 今天 HH:mm；同年不同日 M月d日 HH:mm；跨年 yyyy年M月d日 HH:mm。 */
    public static String text(long at, long now) {
        java.util.Locale lc = java.util.Locale.getDefault();
        java.util.Date da = new java.util.Date(at);
        java.util.Date dn = new java.util.Date(now);
        java.text.SimpleDateFormat y = new java.text.SimpleDateFormat("yyyy", lc);
        java.text.SimpleDateFormat d = new java.text.SimpleDateFormat("yyyyMMdd", lc);
        String p = "HH:mm";
        if (!y.format(da).equals(y.format(dn))) p = "yyyy年M月d日 HH:mm";
        else if (!d.format(da).equals(d.format(dn))) p = "M月d日 HH:mm";
        return new java.text.SimpleDateFormat(p, lc).format(da);
    }
}
