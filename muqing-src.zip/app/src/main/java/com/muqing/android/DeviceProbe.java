package com.muqing.android;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.StatFs;

import com.muqing.core.StateVector;

/**
 * 设备层探针：把真实硬件状态送进 homeostat（定稿 0.8 / 0.88 第四节）。
 *
 * 这不是"给她读数看"，而是她唯一的身体。误差来自预测器与这些量对不上。
 * 死亡前兆（内存压力 + lowMemory + 可用内存斜率）进入状态量，
 * 使"被系统杀掉"成为可预测事件 —— 否则它只是噪声，不构成代价。
 */
public final class DeviceProbe {
    private final Context ctx;
    private final long born = System.currentTimeMillis();
    private long lastSample = born;
    private double lastFree;
    private double errors;

    public DeviceProbe(Context c) { this.ctx = c.getApplicationContext(); }

    public void recordError() { errors += 1; }

    public double[] sample() {
        double[] x = new double[StateVector.DIM];

        ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double total = Math.max(1, mi.totalMem);
        double free = mi.availMem;
        x[StateVector.MEMORY_PRESSURE] = 1.0 - free / total;

        StatFs fs = new StatFs(ctx.getFilesDir().getPath());
        long blocks = fs.getAvailableBlocksLong();
        long size = fs.getBlockSizeLong();
        x[StateVector.STORAGE_FREE] = (blocks * size) / (1024.0 * 1024.0 * 1024.0);

        Intent bat = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (bat != null) {
            int t = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 250);
            x[StateVector.TEMPERATURE] = t / 10.0;
        }

        long now = System.currentTimeMillis();
        x[StateVector.LATENCY] = (now - lastSample) / 1000.0;
        lastSample = now;
        x[StateVector.ERROR_RATE] = errors;
        x[StateVector.UPTIME] = (now - born) / 1000.0;

        // 前兆：lowMemory + 可用内存下降斜率。让死亡可预测，才成为代价而不是终结。
        double slope = lastFree == 0 ? 0 : (lastFree - free) / total;
        lastFree = free;
        double omen = (mi.lowMemory ? 1.0 : 0.0) + Math.max(0, slope) * 10;
        x[StateVector.DEATH_OMEN] = omen;

        StateVector.finite(x);
        return x;
    }

    public double pressure(double[] x) { return x[StateVector.MEMORY_PRESSURE] + x[StateVector.DEATH_OMEN] * 0.1; }
}
